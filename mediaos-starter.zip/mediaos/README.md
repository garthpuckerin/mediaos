# MediaOS — NAS Single-Container Starter

This is a **starter repo** for the single-container **MediaOS** you defined.
It includes:
- **API (Fastify + TypeScript)** — `/packages/api`
- **Web (React + Vite)** — `/packages/web` (served by the API in production)
- **Workers** — `/packages/workers`
- **Adapters (Indexers/Subtitles/Downloaders)** — `/packages/adapters`
- **SQLite (default)** with simple migration placeholder
- **Single container** via `Dockerfile` and `docker-compose.yml` (Synology-friendly)

> Goal: scan/import → request → search → acquire → post-process → library + artwork lock/revert.

## Quick Start (Dev)
```bash
# 1) Node 18+ recommended
corepack enable || npm i -g pnpm

# 2) Install workspaces
pnpm install

# 3) Run API + Web in dev
pnpm -w dev
```

## Build (Prod)
```bash
pnpm -w build
pnpm -w start
```

## Docker (Single Container)
```bash
# Build image
docker build -t mediaos:dev .

# Run (override paths for your NAS)
docker compose up -d
```

## Volumes (Synology)
- `/config` — configs, SQLite DB, logs, artifacts (artwork/subtitle history)
- `/media` — read-only media libraries
- `/downloads` — watch/import folder

## Env
Copy `.env.example` → `.env` and adjust.

## Structure
```
packages/
  api/          # Fastify API + static serving for web dist
  web/          # React+Vite UI (Artwork lock/revert modal included)
  workers/      # Background jobs (queues optional)
  adapters/     # Source adapters (indexers/subtitles/downloaders)
db/
  migrations/   # SQL migrations (sqlite by default)
```

---

**Next:** wire real adapters (indexers/subtitles), and implement the endpoints marked `TODO` in `packages/api/src/routes`.

import 'dotenv/config';

// TODO: connect to queue (in-process or Redis). Implement jobs:
// - scan/import
// - indexer search
// - acquisition
// - post-processing
// - subtitle fetch
// - artwork metadata refresh
console.log('Workers ready (stub)');
